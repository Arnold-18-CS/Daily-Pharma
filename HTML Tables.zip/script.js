document.addEventListener("DOMContentLoaded", function() {
    var sortCheckbox = document.getElementById("sortCheckbox");
    var dataTable = document.getElementById("dataTable");
  
    sortCheckbox.addEventListener("change", function() {
      if (sortCheckbox.checked) {
        dataTable.classList.add("desc");
      } else {
        dataTable.classList.remove("desc");
      }
    });
  });
  