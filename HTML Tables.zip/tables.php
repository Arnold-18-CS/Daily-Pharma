<?php

require_once "connect.php";

$sql = "SELECT * FROM `userdata` ORDER BY username ASC;";
$result = $conn->query($sql);
$data = array();

if ($result->num_rows > 0) {
    echo "<table>";
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}else {
    echo "Error in transfer: " . $conn->error;
}

include_once "index.html";

?>