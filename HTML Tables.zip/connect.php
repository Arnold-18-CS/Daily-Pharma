<?php

$conn = new mysqli('localhost', 'root', '','mysql');

if ($conn->connect_error) {
    die("Error in connecting: " . $conn->connect_error);
}else {
    echo "Connection Succesful.";
}

?>