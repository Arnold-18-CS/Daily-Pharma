<?php

//connect to the database

define('DBSERVER', 'localhost');
define('DBUSERNAME', 'root');
define('DBPASSWORD', '');
define('DBNAME', 'dailyPharma');

$conn = new mysqli(DBSERVER, DBUSERNAME, DBPASSWORD, DBNAME);

if($conn->connect_error){
    die("Error in connection: " . $conn->connect_error);
}


?>