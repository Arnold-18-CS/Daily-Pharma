const activePatient = document.querySelector('.patient');
const activeDoctor = document.querySelector('.doctor');
const activePharmacy = document.querySelector('.pharmacy');
const patientAC = document.querySelector('.login_patient');
const doctorAC = document.querySelector('.login_doctor')
const pharmacyAC = document.querySelector('.login_pharmacy')

activePatient.addEventListener('click', ()=> {
    patientAC.classList.add('active');
    pharmacyAC.classList.remove('active');
    doctorAC.classList.remove('active');
})

activeDoctor.addEventListener('click', ()=> {
    doctorAC.classList.add('active');
    patientAC.classList.remove('active');
    pharmacyAC.classList.remove('active')
})

activePharmacy.addEventListener('click', ()=> {
    pharmacyAC.classList.add('active');
    patientAC.classList.remove('active');
    doctorAC.classList.remove('active')
})

if (sessionStorage.getItem('login_error_flag') === 'true') {
    // Display the error message in a dialog box
    alert(sessionStorage.getItem('login_error'));
  
    // Reset the login error session variables
    sessionStorage.removeItem('login_error');
    sessionStorage.removeItem('login_error_flag');
  }
  